<?php
define('TITLE', 'Profile');
define('PAGE', 'profile');

include('../dbConnection.php');
include('includes/header.php'); 


 if(isset($_SESSION['is_user_login'])){
     $uEmail = $_SESSION['uEmail'];
   
     $sql_user = "SELECT * FROM users where email = '{$uEmail}'";
	 $result_user = $conn->query($sql_user);
	 $row_user = $result_user->fetch_assoc();
	 $user_id = $row_user['id'];
	  
	 $sql_profile = "SELECT * FROM user_profiles WHERE user_id = {$user_id}";
	 $result_profile = $conn->query($sql_profile);
	 $row_profile = $result_profile->fetch_assoc();
 } 
 else {
   echo "<script> location.href='index.php'; </script>";
 }
 
 
?>

<div class="col-sm-4 mb-5">
  <div class="card mt-5 mx-5">
   <div class="card-header">Employee ID : <?php echo $row_user['employee_id']; ?></div>
   <div class="card-body">
	   <h5 class="card-title">Name : <?php echo $row_user['f_name'].' '.$row_user['l_name']; ?></h5>
	   <p class="card-text"><?php echo $row_user['email']; ?></p>
	   <p class="card-text"><?php echo $row_user['mobile']; ?></p>
	   <p class="card-text">Joining Date: <?php echo $row_user['doj']; ?></p>
	   <div class="float-right">
	   <button class="btn btn-danger mr-3" onclick="show()">View</button>
			 <button class="btn btn-secondary" onclick="hide()">Close</button>
	   </div>
   </div>
   </div>  
</div>

<?php 
  include('profile_view.php');
  include('includes/footer.php'); 
  $conn->close();
?>

<script>
      var view = document.getElementById("profile_view");
	  var edit = document.getElementById("profile_edit");
	  view.style.display = "none";
	  edit.style.display = "none";
	  
	function show() {
	  edit.style.display = "none";
	  view.style.display = "block";
	}
	
	function hide() {
	  edit.style.display = "none";
	  view.style.display = "none";
	}
	
	function edits() {
	  view.style.display = "none";
	  edit.style.display = "block";
	}
</script>