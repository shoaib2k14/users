<?php
define('TITLE', 'Profile');
define('PAGE', 'profile');

//include('../dbConnection.php');
$conn = mysqli_connect("localhost","root","","password_engine") or die(mysql_error());

include('includes/header.php'); 

 if(isset($_SESSION['is_user_login'])){
     $uEmail = $_SESSION['uEmail'];
 }else {
     echo "<script> location.href='index.php'; </script>";
 }
 
 if(isset($_REQUEST['view'])){
	  $sql_user = "SELECT * FROM users WHERE id = {$_REQUEST['id']}";
	  $result_user = $conn->query($sql_user);
	  $row_user = $result_user->fetch_assoc();
	  
	  $sql_profile = "SELECT * FROM user_profiles WHERE user_id = {$_REQUEST['id']}";
	  $result_profile = $conn->query($sql_profile);
	  $row_profile = $result_profile->fetch_assoc();
 }
?>

<div class="col-sm-6 mt-5  mx-3">
 <h3 class="text-center">Profile Details</h3>

 <table class="table table-bordered">
  <tbody>
   <tr>
    <td>Name</td>
    <td>
     hhhhh
    </td>
   </tr>
   <tr>
    <td>Email</td>
    <td>
     <?php if(isset($row_user['email'])) {echo $row_user['email']; }?>
    </td>
   </tr>
   <tr>
    <td>Mobile</td>
    <td>
     <?php if(isset($row_user['mobile'])) {echo $row_user['phonecode'].$row_user['mobile']; }?>
    </td>
   </tr>
   <tr>
    <td>DOB</td>
    <td>
     <?php if(isset($row_user['dob'])) {echo $row_user['dob']; }?>
    </td>
   </tr>
   <tr>
    <td>DOJ</td>
    <td>
     <?php if(isset($row_user['doj'])) {echo $row_user['doj']; }?>
    </td>
   </tr>
   <tr>
    <td>Employee Id</td>
    <td>
     <?php if(isset($row_user['employee_id'])) {echo $row_user['employee_id']; }?>
    </td>
   </tr>
   
   
   <tr>
    <td>Department</td>
    <td>
     <?php if(isset($row['department_id'])) {echo $row['department_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Market</td>
    <td>
     <?php if(isset($row['market_id'])) {echo $row['market_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Line Manager</td>
    <td>
     <?php if(isset($row['line_manager_id'])) {echo $row['line_manager_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Office Address</td>
    <td>
     <?php if(isset($row['office_address'])) {echo $row['office_address']; }?>
    </td>
   </tr>
   <tr>
    <td>Country</td>
    <td>
     <?php if(isset($row['country_id'])) {echo $row['country_id']; }?>
    </td>
   </tr>
   <tr>
    <td>State</td>
    <td>
     <?php if(isset($row['state_id'])) {echo $row['state_id']; }?>
    </td>
   </tr>
   <tr>
    <td>City</td>
    <td>
     <?php if(isset($row['city_id'])) {echo $row['city_id']; }?>
    </td>
   </tr>
   <tr>
    <td>Pin Code</td>
    <td>
     <?php if(isset($row['pin_code'])) {echo $row['pin_code']; }?>
    </td>
   </tr>
   <tr>
    <td>Address</td>
    <td>
     <?php if(isset($row['address'])) {echo $row['address']; }?>
    </td>
   </tr>
   <tr>
    <td>Fathers Name</td>
    <td>
     <?php if(isset($row['fathers_name'])) {echo $row['fathers_name']; }?>
    </td>
   </tr>
   <tr>
    <td>Mothers Name</td>
    <td>
     <?php if(isset($row['Mothers_name'])) {echo $row['Mothers_name']; }?>
    </td>
   </tr>
   
   </tbody>
 </table>
 <div class="text-center">
  <form class='d-print-none d-inline mr-3'><input class='btn btn-danger' type='submit' value='Print' onClick='window.print()'></form>
  <form class='d-print-none d-inline' action="work.php"><input class='btn btn-secondary' type='submit' value='Close'></form>
 </div>
</div>

<?php
include('includes/footer.php'); 
?>