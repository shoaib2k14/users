<?php
define('TITLE', 'Role');
define('PAGE', 'role');

include('../dbConnection.php');
include('includes/header.php'); 

 if(isset($_SESSION['is_user_login'])){
	  $uEmail = $_SESSION['uEmail'];
	  $sql_user_id = "SELECT id, email FROM users WHERE email='".$uEmail."' limit 1";
	  $result_user_id = $conn->query($sql_user_id);
	  $row_user_id = $result_user_id->fetch_assoc();
	  $uID = $row_user_id['id'];
 } else {
  echo "<script> location.href='index.php'; </script>";
 }
?>
  

<div class="col-sm-9 col-md-10 mt-5">
 <p class="p-2 mb-4 h2">Assigned Role</p>
  <?php 
 $sql = "SELECT roles.role as role,roles.created_at,markets.market as market FROM grants, roles, markets where grants.user_id = {$uID} and grants.status = 1 and grants.role_id = roles.id and roles.market_id = markets.id ";
 
 $result = $conn->query($sql);
 if($result->num_rows > 0){ ?>
  <table class="table table-hovered table-striped" id="productTable">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Role</th>
      <th scope="col">Market</th>
      <th scope="col">Assigned Date</th>
	  <th scope="col">Get Password</th>
    </tr>
  </thead>
  <tbody>
  <?php while($row = $result->fetch_assoc()){ ?>
    <tr>
		<th scope="row">1</th>
		<td><?php echo $row["role"]; ?></td>
		<td><?=$row["market"]?></td>
		<td><?=$row["created_at"]?></td>
		<td>
		  <button class="btn btn-danger mr-3" onclick="getDetails('<?=$row["role"]?>','<?=$row["market"]?>')">Get Password</button>
		  
		</td>
    </tr>
   <?php } ?>
   </tbody> </table>
  <?php } 
   else {
    echo "0 Result";
  }
  ?>
</div>


<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Open modal</button>-->



<!-- The Modal -->
<div id="getPasswordRequestModal">

</div>
<!-- Model -->

<a class="btn btn-danger box" href="role-request.php"><i class="fas fa-plus fa-2x"></i></a>
</div>

<?php 
  include('includes/footer.php'); 
  $conn->close();
?>

<script>
function getDetails(role,market) {
	 //alert(role + market);
	 $.ajax({
		 url:'modal/getPasswordRequestModal.php',
		 type:'POST',
		 data:{
			   role:role,
			   market:market,
			 },
		 success:function(result){
			 $('#getPasswordRequestModal').html(result);
			 $('#myModal').modal('show');
		 }
	 });
 }
 
 $(document).ready(function(){
	$('#productTable').DataTable();
 });
 
</script>