<?php

define('TITLE', 'Dashboard');
define('PAGE', 'dashboard');

include('../dbConnection.php');
include('includes/header.php'); 



 if(isset($_SESSION['is_user_login'])){
     $uEmail = $_SESSION['uEmail'];
     
	 $sql = "SELECT * FROM users where email = '{$uEmail}'";
	 $result = $conn->query($sql);
	 $row = $result->fetch_assoc();
	 $user_id = $row['id'];
	 $user_name = $row['f_name'];
	 
 } else {
  echo "<script> location.href='index.php'; </script>";
 }
 
 
 $sql_assigned = "SELECT count(*) as assigned FROM grants where user_id = $user_id";
 $result_assigned = $conn->query($sql_assigned);
 $row_assigned = mysqli_fetch_array($result_assigned);
 $assigned_role = $row_assigned['assigned'];

 $sql_declined = "SELECT count(*) as declined FROM role_requests where user_id = $user_id and is_declined = 1";
 $result_declined = $conn->query($sql_declined);
 $row_declined = mysqli_fetch_array($result_declined);
 $declined_role = $row_declined['declined'];

 $sql_pending = "SELECT count(*) as pending FROM role_requests where user_id = $user_id and is_pending = 1";
 $result_pending = $conn->query($sql_pending);
 $row_pending = mysqli_fetch_array($result_pending);
 $pending_role = $row_pending['pending'];

 
 // I'm India so my timezone is Asia/Calcutta
     date_default_timezone_set('Asia/Calcutta');

 // 24-hour format of an hour without leading zeros (0 through 23)
     $Hour = date('G');

	if ( $Hour >= 5 && $Hour <= 11 ) {
		$grettings = "Good Morning";
	} else if ( $Hour >= 12 && $Hour <= 17 ) {
		$grettings = "Good Afternoon";
	} else if ( $Hour >= 15 || $Hour <= 4 ) {
		$grettings = "Good Evening";
	}

?>
<div class="col-sm-9 col-md-10">
  <div class="col-12 mt-5">
	  <h3>Hello <?php echo $user_name." ".$grettings;?></h3>
	  <p>Welcome to _VOIS</p>
  </div>
  <div class="row mx-5 text-center">
    <div class="col-sm-4 mt-5">
      <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
        <div class="card-header">Assigned Role</div>
        <div class="card-body">
          <h4 class="card-title">
            <?php echo $assigned_role; ?>
          </h4>
          <a class="btn text-white" href="role-assigned.php">View</a>
        </div>
      </div>
    </div>
    <div class="col-sm-4 mt-5">
      <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
        <div class="card-header">Requested Role</div>
        <div class="card-body">
          <h4 class="card-title">
            <?php echo $pending_role; ?>
          </h4>
          <a class="btn text-white" href="role-requested.php">View</a>
        </div>
      </div>
    </div>
    <div class="col-sm-4 mt-5">
      <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
        <div class="card-header">Declined Role</div>
        <div class="card-body">
          <h4 class="card-title">
            <?php echo $declined_role; ?>
          </h4>
          <a class="btn text-white" href="role-requested.php">View</a>
        </div>
      </div>
    </div>
  </div>  
</div>
<?php
include('includes/footer.php'); 
?>