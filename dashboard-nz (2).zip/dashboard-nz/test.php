<?php
$conn = mysqli_connect('localhost', 'root', '', 'Vodafone-Nz');

if(isset($_POST['submit'])){
	require('PHPExcel\Classes\PHPExcel.php');
	require('PHPExcel\Classes\PHPExcel\IOFactory.php');
	
	$file = $_FILES['doc']['tmp_name'];
	
	$obj = PHPExcel_IOFactory::load($file);
	
	foreach($obj->getWorksheetIterator() as $sheet){
		$getHighestRow = $sheet->getHighestRow();
		for($i=2; $i<=$getHighestRow; $i++){
			$column_0 = $sheet->getCellByColumnAndRow(0,$i)->getValue();
			$column_1 = $sheet->getCellByColumnAndRow(1,$i)->getValue();
			$column_2 = $sheet->getCellByColumnAndRow(2,$i)->getValue();
			$column_3 = $sheet->getCellByColumnAndRow(3,$i)->getValue();
			$column_4 = $sheet->getCellByColumnAndRow(4,$i)->getValue();
			$column_5 = $sheet->getCellByColumnAndRow(5,$i)->getValue();
			$column_6 = $sheet->getCellByColumnAndRow(6,$i)->getValue();
			$column_7 = $sheet->getCellByColumnAndRow(7,$i)->getValue();
			$column_8 = $sheet->getCellByColumnAndRow(8,$i)->getValue();
			$column_9 = $sheet->getCellByColumnAndRow(9,$i)->getValue();
			$column_10 = $sheet->getCellByColumnAndRow(10,$i)->getValue();
			$column_11 = $sheet->getCellByColumnAndRow(11,$i)->getValue();
			$column_12 = $sheet->getCellByColumnAndRow(12,$i)->getValue();
			$column_13 = $sheet->getCellByColumnAndRow(13,$i)->getValue();
			$column_14 = $sheet->getCellByColumnAndRow(14,$i)->getValue();
			$column_15 = $sheet->getCellByColumnAndRow(15,$i)->getValue();
			$column_16 = $sheet->getCellByColumnAndRow(16,$i)->getValue();
			$column_17 = $sheet->getCellByColumnAndRow(17,$i)->getValue();
			$column_18 = $sheet->getCellByColumnAndRow(18,$i)->getValue();
			$column_19 = $sheet->getCellByColumnAndRow(19,$i)->getValue();
			$column_20 = $sheet->getCellByColumnAndRow(20,$i)->getValue();
			$column_21 = $sheet->getCellByColumnAndRow(21,$i)->getValue();
			$column_22 = $sheet->getCellByColumnAndRow(22,$i)->getValue();
			$column_23 = $sheet->getCellByColumnAndRow(23,$i)->getValue();
			$column_24 = $sheet->getCellByColumnAndRow(24,$i)->getValue();
			$column_25 = $sheet->getCellByColumnAndRow(25,$i)->getValue();
			$column_26 = $sheet->getCellByColumnAndRow(26,$i)->getValue();
			$column_27 = $sheet->getCellByColumnAndRow(27,$i)->getValue();
			$column_28 = $sheet->getCellByColumnAndRow(28,$i)->getValue();
			$column_29 = $sheet->getCellByColumnAndRow(29,$i)->getValue();
			$column_30 = $sheet->getCellByColumnAndRow(30,$i)->getValue();
			$column_31 = $sheet->getCellByColumnAndRow(31,$i)->getValue();
			$column_32 = $sheet->getCellByColumnAndRow(32,$i)->getValue();
			$column_33 = $sheet->getCellByColumnAndRow(33,$i)->getValue();
			$column_34 = $sheet->getCellByColumnAndRow(34,$i)->getValue();
			$column_35 = $sheet->getCellByColumnAndRow(35,$i)->getValue();
			
			$column_36 = gettype($sheet->getCellByColumnAndRow(36,$i)->getValue()) == 'double' ? gmdate("Y-m-d",($sheet->getCellByColumnAndRow(36,$i)->getValue() - 25569) * 86400) : $sheet->getCellByColumnAndRow(36,$i)->getValue();
			
			$column_37 = gettype($sheet->getCellByColumnAndRow(37,$i)->getValue()) == 'double' ? gmdate("Y-m-d",($sheet->getCellByColumnAndRow(37,$i)->getValue() - 25569) * 86400) : $sheet->getCellByColumnAndRow(37,$i)->getValue();
			
			$column_38 = gettype($sheet->getCellByColumnAndRow(38,$i)->getValue()) == 'double' ? gmdate("Y-m-d",($sheet->getCellByColumnAndRow(38,$i)->getValue() - 25569) * 86400) : $sheet->getCellByColumnAndRow(38,$i)->getValue();
			
			$column_39 = gettype($sheet->getCellByColumnAndRow(39,$i)->getValue()) == 'double' ? gmdate("Y-m-d",($sheet->getCellByColumnAndRow(39,$i)->getValue() - 25569) * 86400) : $sheet->getCellByColumnAndRow(39,$i)->getValue();
			
			$column_40 = gettype($sheet->getCellByColumnAndRow(40,$i)->getValue()) == 'double' ? gmdate("Y-m-d",($sheet->getCellByColumnAndRow(40,$i)->getValue() - 25569) * 86400) : $sheet->getCellByColumnAndRow(40,$i)->getValue();
			
			$column_41 = $sheet->getCellByColumnAndRow(41,$i)->getValue();
			
			$column_42 = $sheet->getCellByColumnAndRow(42,$i)->getValue();
			
			
			
			mysqli_query($conn, "INSERT INTO `servers` (`red/blue`, `os_family`, `host_name`, `service`, `parent_application`, `business_owner`, `application_support`, `internet_facing`, `business_priority`, `service_impact`, `environment`, `server_type`, `server_os`, `hardware/host_plateform`, `cluster`, `cpu`, `sockets`, `cores/socket`, `server_database`, `serial_no`, `make`, `model`, `tssc_suppot_level`, `oob_ip`, `backup_ip`, `prod_ip`, `jump_host`, `ilo/console_ip`, `part_no`, `cluster_site`, `site_address`, `row`, `cab`, `project_name`, `operating_system_support`, `hardware_vendor_support`, `warranty_start_date`, `warranty_end_date`, `entered_date`, `exit_date`, `install_date`, `documentation`, `comments`) VALUES ('$column_0', '$column_1', '$column_2', '$column_3', '$column_4', '$column_5', '$column_6', '$column_7', '$column_8', '$column_9', '$column_10', '$column_11', '$column_12', '$column_13', '$column_14', '$column_15', '$column_16', '$column_17', '$column_18', '$column_19', '$column_20', '$column_21', '$column_22', '$column_23', '$column_24', '$column_25', '$column_26', '$column_27', '$column_28', '$column_29', '$column_30', '$column_31', '$column_32', '$column_33', '$column_34', '$column_35', '$column_36', '$column_37', '$column_38', '$column_39', '$column_40', '$column_41', '$column_42');");
		}
	}
}

?>


<form method="post" enctype="multipart/form-data">
	<input type="file" name="doc"/>
	<input type="submit" name="submit"/>
</form>