<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="content-type" content="text/html;charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
  <meta name="viewport" content="width=device-width" />

  <title>Dashboard</title>

  <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
  
  <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>
  
  <link href="assets/css/demo.css" rel="stylesheet" />

  <link href="assets/css/themify-icons.css" rel="stylesheet">
  
  <link href="assets/css/dataTables.css" rel="stylesheet" type="text/css" >
   
  <link href="assets/css/custom.css" rel="stylesheet" />

  <style>
    p{
		font-size: 13px;
		line-height: 1.4em;
	}
	.table > thead > tr > th {
		font-size: 1em;
	}
	
	.card .table tbody td:last-child, .card .table thead th:last-child {
		padding-right: 15px;
		white-space: nowrap;
	}
	
	.sidebar .sidebar-wrapper {
		position: relative;
		overflow: hidden;
		width: 215px;
		z-index: 4;
		height: 100vh;
		box-shadow: inset -1px 0px 0px 0px #dddddd;
		background: linear-gradient(28deg,#e60000 0%,#900);
	}
	.sidebar .nav p, .off-canvas-sidebar .nav p {
		margin: 0;
		line-height: 30px;
		font-size: 14px;
		font-weight: 400;
		text-transform: capitalize;
		color: #fff;
	}
	
	.sidebar .nav i{
		font-size: 18px;
		float: left;
		margin-right: 10px;
		line-height: 30px;
		width: 30px;
		text-align: center;
		color: #fff;
	}
	
	.sidebar .logo .simple-text, .sidebar[data-background-color="white"] .logo .simple-text, .off-canvas-sidebar .logo .simple-text, .off-canvas-sidebar[data-background-color="white"] .logo .simple-text {
		color: #ffffff;
		font-size: 3rem;
	}
	
	.col-xs-7 {
		width: 58.33333333%;
		padding: 0 6px 0px 0px;
	}
	tr{
		text-transform: capitalize;
	}
	
	table.dataTable tfoot th, table.dataTable tfoot td {
		border-top: 0px solid #111;
		padding: 10px 18px 6px 6px;
	}
	tfoot{
		display: table-header-group;
	}
	button, input, select, textarea {
		font-family: inherit;
		font-size: inherit;
		line-height: inherit;
		margin-bottom: 15px;
		border: 1px solid lightgray;
		padding: 6px;
		font-weight: 400;
	}
	thead tr{
		background: #9b9999;
		color: #fff;
	}
	
	table.dataTable thead th, table.dataTable thead td {
		padding: 10px 9px;
		border-bottom: 0px solid #111;
	}
	
	.dataTables_wrapper .dataTables_filter {
		float: left;
		text-align: left;
		margin-left: 5.8%;
	}
	.dataTables_wrapper .dataTables_paginate {
		float: left;
		text-align: left;
		padding-top: 0.25em;
		margin-left: 3.8%;
	}
	
	.main-panel > .content {
		padding: 0px 0px;
		min-height: calc(100vh - 123px);
	}
	
	table.dataTable, table.dataTable th, table.dataTable td {
		box-sizing: content-box;
		margin-bottom: 25px;
	}
	
	
	
	@media (min-width: 992px){
		.col-md-12 {
			width: 100%;
			display: flex;
			overflow-x: auto;
			overflow-y: hidden;
		}
	}
  </style>
</head>


<body>

<?php
$conn = mysqli_connect('localhost', 'root', '', 'Vodafone-Nz');
$sql = "SELECT * FROM servers";
  $result = mysqli_query($conn,$sql);
?>

<div class="wrapper">
  <div class="sidebar" data-background-color="white" data-active-color="danger">

    
    <div class="sidebar-wrapper">
      <div class="logo">
        <a href="#" class="simple-text">
			_VOIS
        </a>
      </div>

      <ul class="nav">
        <li class="active">
          <a href="servers.php">
            <div class="icon-big icon-warning text-center">
			  <i class="ti-server"></i>
			</div>
            <p>Servers</p>
          </a>
        </li>
        <li>
          <a href="home.php">
            <div class="icon-big icon-success text-center">
			  <i class="ti-wallet"></i>
			</div>
            <p>Home</p>
          </a>
        </li>
      </ul>
    </div>
  </div>

  <div class="main-panel">
    
	  <div class="content">
       <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            
			<div class="card card-table" id="FileSystem">
              <div class="header">
                <h4 class="title">Servers</h4>
              </div>
			  
			  
              <div class="content table-responsive table-full-width">
                <table class="table table-striped dtExample" id="example">
				<tfoot>
					  <th>#</th>
					  <th>red/blue</th>
					  <th>os_family</th>
					  <th>host_name</th>
					  <th>service</th>
					  <th>parent_application</th>
					  <th>business_owner</th>
					  <th>application_support</th>
					  <th>internet_facing</th>
					  <th>business_priority</th>
					  <th>service_impact</th>
					  <th>environment</th>
					  <th>server_type</th>
					  <th>server_os</th>
					  <th>hardware/host_plateform</th>
					  <th>cluster</th>
					  <th>cpu</th>
					  <th>sockets</th>
					  <th>cores/socket</th>
					  <th>server_database</th>
					  <th>serial_no</th>
					  <th>make</th>
					  <th>model</th>
					  <th>tssc_suppot_level</th>
					  <th>oob_ip</th>
					  <th>backup_ip</th>
					  <th>prod_ip</th>
					  <th>jump_host</th>
					  <th>ilo/console_ip</th>
					  <th>part_no</th>
					  <th>cluster_site</th>
					  <th>site_address</th>
					  <th>row</th>
					  <th>cab</th>
					  <th>project_name</th>
					  <th>operating_system_support</th>
					  <th>hardware_vendor_support</th>
					  <th>warranty_start_date</th>
					  <th>warranty_end_date</th>
					  <th>entered_date</th>
					  <th>exit_date</th>
					  <th>install_date</th>
					  <th>documentation</th>
					  <th>comments</th>
                  </tfoot >
                  <thead>
					  <th>#</th>
					  <th>red/blue</th>
					  <th>os_family</th>
					  <th>host_name</th>
					  <th>service</th>
					  <th>parent_application</th>
					  <th>business_owner</th>
					  <th>application_support</th>
					  <th>internet_facing</th>
					  <th>business_priority</th>
					  <th>service_impact</th>
					  <th>environment</th>
					  <th>server_type</th>
					  <th>server_os</th>
					  <th>hardware/host_plateform</th>
					  <th>cluster</th>
					  <th>cpu</th>
					  <th>sockets</th>
					  <th>cores/socket</th>
					  <th>server_database</th>
					  <th>serial_no</th>
					  <th>make</th>
					  <th>model</th>
					  <th>tssc_suppot_level</th>
					  <th>oob_ip</th>
					  <th>backup_ip</th>
					  <th>prod_ip</th>
					  <th>jump_host</th>
					  <th>ilo/console_ip</th>
					  <th>part_no</th>
					  <th>cluster_site</th>
					  <th>site_address</th>
					  <th>row</th>
					  <th>cab</th>
					  <th>project_name</th>
					  <th>operating_system_support</th>
					  <th>hardware_vendor_support</th>
					  <th>warranty_start_date</th>
					  <th>warranty_end_date</th>
					  <th>entered_date</th>
					  <th>exit_date</th>
					  <th>install_date</th>
					  <th>documentation</th>
					  <th>comments</th>
                  </thead>
                  <tbody>
				    <?php
					   foreach( $result as $key=>$row ){ ?>
						<tr>
							<td><?=++$key?></td>
							<td><?=$row["red/blue"]?></td>
							<td><?=$row["os_family"]?></td>
							<td><?=$row["host_name"]?></td>
							<td><?=$row["service"]?></td>
							<td><?=$row["parent_application"]?></td>
							<td><?=$row["business_owner"]?></td>
							<td><?=$row["application_support"]?></td>
							<td><?=$row["internet_facing"]?></td>
							<td><?=$row["business_priority"]?></td>
							<td><?=$row["service_impact"]?></td>
							<td><?=$row["environment"]?></td>
							<td><?=$row["server_type"]?></td>
							<td><?=$row["server_os"]?></td>
							<td><?=$row["hardware/host_plateform"]?></td>
							<td><?=$row["cluster"]?></td>
							<td><?=$row["cpu"]?></td>
							<td><?=$row["sockets"]?></td>
							<td><?=$row["cores/socket"]?></td>
							<td><?=$row["server_database"]?></td>
							<td><?=$row["serial_no"]?></td>
							<td><?=$row["make"]?></td>
							<td><?=$row["model"]?></td>
							<td><?=$row["tssc_suppot_level"]?></td>
							<td><?=$row["oob_ip"]?></td>
							<td><?=$row["backup_ip"]?></td>
							<td><?=$row["prod_ip"]?></td>
							<td><?=$row["jump_host"]?></td>
							<td><?=$row["ilo/console_ip"]?></td>
							<td><?=$row["part_no"]?></td>
							<td><?=$row["cluster_site"]?></td>
							<td><?=$row["site_address"]?></td>
							<td><?=$row["row"]?></td>
							<td><?=$row["cab"]?></td>
							<td><?=$row["project_name"]?></td>
							<td><?=$row["operating_system_support"]?></td>
							<td><?=$row["hardware_vendor_support"]?></td>
							<td><?=$row["warranty_start_date"]?></td>
							<td><?=$row["warranty_end_date"]?></td>
							<td><?=$row["entered_date"]?></td>
							<td><?=$row["exit_date"]?></td>
							<td><?=$row["install_date"]?></td>
							<td><?=$row["documentation"]?></td>
							<td><?=$row["comments"]?></td>
						</tr>
					<?php } ?>
				  </tbody>
                </table>
			  </div>
            </div>
		</div>
	   </div>
      </div>
    </div>
  </div>	
</div>

</body>

<!--   Core JS Files   -->
<script src="assets/js/jquery.min.js" type="text/javascript"></script>

<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

<script src="assets/js/paper-dashboard.js"></script>

<script src="assets/js/demo.js"></script>

<script src="assets/js/jquery.sharrre.js"></script>

<script src="assets/js/dataTables.js" type="text/javascript" charset="utf8" ></script>

<script>
	$(document).ready( function () {
		$('#Example').DataTable();
	});
	
	$('.card-table').hide();
	$('#FileSystem').show();
	
	function show(e){
		$('.card .content').removeClass('active-tab');
		$(e).find('.card .content').addClass('active-tab');
		$('.card-table').hide();
		let key = $(e).attr('key');
		$('#'+key).show();
	}
	
	
	$(document).ready(function () {
    // Setup - add a text input to each footer cell
    $('#example tfoot  th').each(function () {
        var title = $(this).text();
        $(this).html('<input type="text" placeholder="Search ' + title + '" />');
    });
 
    // DataTable
    var table = $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api()
                .columns()
                .every(function () {
                    var that = this;
 
                    $('input', this.footer()).on('keyup change clear', function () {
                        if (that.search() !== this.value) {
                            that.search(this.value).draw();
                        }
                    });
                });
        },
    });
});
</script>

</html>
