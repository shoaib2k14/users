<?php
$table_name = "passwordEncryption";
$alert = "";

include('controller/select.php');
include("includes/header.php");
?>

<style>
.source, .target{
	background: #f1f1f1;
    margin: 5px;
    padding-bottom: 20px;
    border-radius: 4px;
}

.source-heading, .target-heading{
	margin: 20px 5px 10px 5px;
}

</style>


<div class="page-wrapper">
	<div class="content container-fluid">
	  
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Logs</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-2">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Logs</li>
					</ol>
				</div>
			</div>
		</div>
		
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					 <div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th style="width: 0px;">#</th>
										<th>Logs</th>
									</tr>
								</thead>
								<tbody>
								 
								</tbody>
							</table>
						</div>
					</div>
				 </div>
			 </div>
		  </div>
	  </div>
   </div>
</div>

<!-- jQuery -->
<script>  
	var element = document.getElementById("Logs");
	   element.classList.add("active");
	  
</script>
<?php include("includes/footer.php"); ?>
	
