<?php
$table_name = "markets";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>
<style>
table, th, td {
  border: 1px solid #ebe8e8  !important;
  border-collapse: collapse;
}
</style>

<div class="page-wrapper">
	<div class="content container-fluid">
	
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Manual Restart</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Manual Restart</li>
					</ol>
				</div>
			</div>
		</div>
		
		<div class="page-header">
			<div class="row">
			    <div class="col-md-2">
					<div class="form-group">
						<select class="form-control" id="market" name="market" onchange="getMarket(this.value)">
							<option value="" disabled selected>--Select Market--</option>
							<option value="group">Group</option>
							<option value="germany">Germany</option>
							<option value="italy">Italy</option>
							<option value="spain">Spain</option>
						</select>
					</div>
				</div>
				
				<div class="col-md-3">
					<div class="form-group">
						<select class="form-control" id="service" name="service">
							<option value="" disabled selected>--Select Service--</option>
						</select>
					</div>
				</div>
				
				<div class='col-sm-2'>
					<div class="form-group">
						<div class='input-group date' id='datetimepicker1'>
							<input type="date" class="form-control" />
						</div>
					</div>
				</div>
				
				
				<div class="col-md-4">
					<div class="form-group input-group mb-3">
					  <input type="text" class="form-control" placeholder="Server name">
					  <div class="input-group-append">
						<button class="btn btn-danger" type="button">validate</button>
					  </div>
					</div>
				</div>
			
			
			
			
			   <div class="col-sm-6">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th style="width: 0px;">#</th>
										<th>Logs</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>1</td>
										<td>ddd fff fff fff fff</td>
									</tr>
									<tr>
										<td>2</td>
										<td>ddd fff fff fff fff</td>
									</tr>
									<tr>
										<td>3</td>
										<td>ddd fff fff fff fff</td>
									</tr>
									<tr>
										<td>4</td>
										<td>ddd fff fff fff fff</td>
									</tr>
									<tr>
										<td>5</td>
										<td>ddd fff fff fff fff</td>
									</tr>
								</tbody>
							</table>
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">Launch demo modal</button>
						</div>
					</div>
				</div>
			</div>
		 </div>
	  </div>
   </div>
</div>
	
	
	
<!-- Modal's -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
		<div style="display:flex;justify-content: space-around;">
			<div class="card border-danger mb-3" style="max-width: 18rem;">
			  <div class="card-header">Previous Process Logs</div>
			  <div class="card-body">
				<h5 class="card-title">Secondary card title</h5>
				<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
			  </div>
			</div>
			
			<div class="card border-primary mb-3" style="max-width: 18rem;">
			  <div class="card-header">Curret Process Logs</div>
			  <div class="card-body">
				<h5 class="card-title">Secondary card title</h5>
				<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
			  </div>
			</div>
		</div>
		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger">Save</button>
      </div>
    </div>
  </div>
</div>
<!-- Model's -->

	
	
<!-- jQuery -->
<script>
$(document).ready(function() {
	$('#market').select2({
		placeholder: "--Select Market--",
		allowClear: true
	});
});
</script>

<script>
	var element = document.getElementById("Manual");
	   element.classList.add("active");
	   
	function myFunction(id) {
	   document.getElementById("primary_key_delete").setAttribute('value',id);
	}
</script>

<?php include("includes/footer.php"); ?>
	