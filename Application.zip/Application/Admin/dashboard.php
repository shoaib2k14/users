<?php
$table_name = "dashboard";

include('controller/select.php');
include("includes/header.php");

?>

<style>
.box-shadow{
	box-shadow: 1px 1px 4px 0px grey;
}
.card board1::hover{
	scale:1.2;
}
</style>


<style>
body .container-fluid {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  margin: 0px;
  
}

body .container-fluid .card {
  background: #232427db;
  position: relative;
  min-width: 25%;
  height: 170px;
  box-shadow: inset 5px 5px 5px rgba(0, 0, 0, 0.2),
    inset -5px -5px 15px rgba(255, 255, 255, 0.1),
    5px 5px 15px rgba(0, 0, 0, 0.3), -5px -5px 15px rgba(255, 255, 255, 0.1);
  border-radius: 15px;
  margin: 15px 15px 25px 15px;
  transition: 0.5s;
}

body .container-fluid .card:nth-child(1) .box .content a {
  background: #2196f3;
}

body .container-fluid .card:nth-child(2) .box .content a {
  background: #e91e63;
}

body .container-fluid .card:nth-child(3) .box .content a {
  background: #23c186;
}

body .container-fluid .card .box {
  position: absolute;
  top: 15px;
  bottom: 15px;
  left: 15px;
  right: 15px;
  background: #2a2b2f;
  border-radius: 15px;
  overflow: hidden;
  transition: 0.5s;
  width:91%;
}

body .container-fluid .card .box:hover {
  transform: translateY(-50px);
}

body .container-fluid .card .box:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 50%;
  height: 100%;
  background: rgba(255, 255, 255, 0.03);
}

body .container-fluid .card .box .content {
  padding: 20px;
  text-align: center;
}

body .container-fluid .card .box .content h2 {
  position: absolute;
  top: -10px;
  right: 30px;
  font-size: 4rem;
  color: rgb(255 255 255 / 38%);
}

body .container-fluid .card .box .content h3 {
  font-size: 1.8rem;
  color: #fff;
  z-index: 1;
  transition: 0.5s;
  margin-bottom: 15px;
  text-align:start;
}

body .container-fluid .card .box .content p {
  font-size: 1rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.9);
  z-index: 1;
  transition: 0.5s;
}

body .container-fluid .card .box .content a {
  position: relative;
  display: inline-block;
  padding: 8px 20px;
  border-radius: 5px;
  text-decoration: none;
  color: white;
  margin-top: 20px;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  transition: 0.5s;
  width:40%;
}
body .container-fluid .card .box .content a:hover {
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.6);
  background: #fff;
  color: #000;
}

.text-heading{
	color: #ffff !important;
	font-size: 26px !important;
	position: absolute !important;
	bottom: 4rem !important;
	left: 10px !important;
}

.button-heading{
	position: absolute !important;
	left: 10% !important;
	bottom: 12px !important;
}

</style>


<div class="page-wrapper">
    <div class="content container-fluid-fluid">
	
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Dashboard</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Dashboard</li>
					</ol>
				</div>
			</div>
		</div>
		
		
        <div class="page-header">
			<div class="row">
				<div class="col-sm-12">
				    <h3 class="page-title mt-3"><?php echo $grettings.' '.$aFName." ".$aLName; ?></h3>
					<p class="page-paragraph">Welcome to _VOIS</p>
				</div>
			</div>
		</div>
		
		<div class="container-fluid">
		  
			  <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$requested_roles;?></h2>
					<h3 class="text-heading">Restart Requests</h3>
					<a href="restart-request.php" class="button-heading">View</a>
				  </div>
				</div>
			  </div>
		  
			  <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$all_users;?></h2>
					<h3 class="text-heading">Failure</h3>
					<a href="failure.php" class="button-heading">View</a>
				  </div>
				</div>
			  </div>
		  
		      <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$all_roles;?></h2>
					<h3 class="text-heading">Success</h3>
					<a href="success.php" class="button-heading btn-secondary">View</a>
				  </div>
				</div>
			  </div>
		 
		</div>
	 </div>
  </div>
  
	
	
<!-- JQuery -->
<?php include("includes/footer.php"); ?>
<script>
	var element = document.getElementById("dashboard");
	   element.classList.add("active");
</script>
