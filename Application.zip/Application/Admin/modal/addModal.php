<?php

$modalName = "addModal";

include('../controller/modal.php');

$mSql = "SELECT * FROM markets WHERE status = 1 ORDER BY market";
 $mResult = $conn->query($mSql);

$serverSql = "SELECT id,host_name,ip_address from servers WHERE market_id = 1";
 $serverResult = $conn->query($serverSql);
 
$roleSql = "SELECT id,role from roles WHERE market_id = 1";
 $roleResult = $conn->query($roleSql);

?>


<style>
#assignServer .modal-content, #assignRole .modal-content{
    background-color: #f5f5f5;
}
</style>


<?php
$SqlServer = "SELECT * FROM servers WHERE market_id = 1";
	$sResult = $conn->query($SqlServer);
	$tResult = $conn->query($SqlServer);
	
$SqlUser = "SELECT * FROM users WHERE market_id = 1";
	$uResult = $conn->query($SqlUser);

if($key == 'addSSH'){?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Create SSH</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
            <form id="addFormData">
								<div class="row formtype">
									<div class="col-md-12">
									   <div class="form-group">
										  <label>Reference Request ID<span class="text-danger">*</span></label>
										  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
										  <div id="ErrorTicket" class="form-control-error"></div>
									   </div>
									</div>
								</div>
								
								<p class="source-heading">Fill Source Details </p>
								<div class="source row formtype">
									<div class="col-md-6">
										<div class="form-group">
											<label>Select Source Server<span class="text-danger">*</span></label>
											<select class="form-control" id="sourceServer" name="sourceServer" onchange="getSourceUser(this.value)">
												<option value="" disabled selected>Select</option>
												  <?php while($sRow = $sResult->fetch_assoc()){ ?>  
													<option value="<?php echo $sRow['id']; ?>"> <?php echo $sRow['host_name']; ?> </option>  
												  <?php }?>
											</select>
											<div id="ErrorSourceServer" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Source Source User<span class="text-danger">*</span></label>
											<select class="form-control" id="sourceUser" name="sourceUser">
												<option value="" disabled selected>Select</option>
											</select>
											<div id="ErrorSourceUser" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Source Account Type<span class="text-danger">*</span></label>
											<select class="form-control" id="sourceAccountType" name="sourceAccountType">
												<option value="" disabled selected>Select</option>
												<option value="1">Service</option>
												<option value="2">Funnctional</option>
												<option value="3">Local</option>
											</select>
											<div id="ErrorAccountType" class="form-control-error"></div>
										</div>
									</div>
									<!--
									<div class="col-md-12">
										<div class="form-group">
											<label>Source UserName SSH Key<span class="text-danger">*</span></label>
											<textarea class="form-control" type="text" id="sourceSSHKey" name="sourceSSHKey" placeholder="Add SSH Key"></textarea>
											<div id="ErrorSSH" class="form-control-error"></div>
										</div>
									</div>
									-->
								</div>
								
								<p  class="target-heading">Fill Target Details</p>		
								<div class="target row formtype">
									<div class="col-md-6">
										<div class="form-group">
											<label>Select Target ServerName <span class="text-danger">*</span></label>
											<select class="form-control" id="targetServer" name="targetServer" onchange="getTargetUser(this.value)">
												<option value="" disabled selected>Select</option>
												  <?php while($tRow = $tResult->fetch_assoc()){ ?>  
													<option value="<?php echo $tRow['id']; ?>"> <?php echo $tRow['host_name']; ?> </option>  
												  <?php }?>
											</select>
											<div id="ErrorTargetServer" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Source Source User<span class="text-danger">*</span></label>
											<select class="form-control" id="targetUser" name="targetUser">
												<option value="" disabled selected>Select</option>
											</select>
											<div id="ErrorTargetUser" class="form-control-error"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="modal-footer float-right">
							  <button type="button" class="btn btn-danger" onclick="addSSHKey('&key=AddUserServer')">Save</button>
							  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
						   </div>
						</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
	
<?php } ?>


<?php
if($key == 'addAdmin'){?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Admin</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertAdmin">
				<div class="row formtype">
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name">
							<div id="ErrorFName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name">
							<div id="ErrorLName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
							<div id="ErrorEmail" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile Number</label>
							<input class="form-control" type="number" name="mobile">
							<div id="ErrorMobile" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertAdmin')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'addRole'){?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Role</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertRole">
				<div class="row formtype">
				    <!--
					<div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					-->
					<div class="col-md-12">
						<div class="form-group">
							<label>Role Name</label>
							<input class="form-control" type="text" name="role" placeholder="Add role name">
							<div id="ErrorRole" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertRole')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>






<?php
if($key == 'addMarket'){?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Market</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertMarket">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Market</label>
							<input class="form-control" type="text" name="market">
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertMarket')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'addOwner'){?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Owner</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertOwner">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Owner</label>
							<input class="form-control" type="text" name="owner">
							<div id="ErrorOwner" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
							<div id="ErrorEmail" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertOwner')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>



<?php
if($key == 'addServer'){ ?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Server</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertServer">
				<div class="row formtype">
				    
					 <div class="col-md-12">
					   <div class="form-group">
						  <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Server Name</label>
							<input class="form-control icon-rtl" type="text" name="host" id="host" placeholder="Server Name" onfocusout="validateServer()"/>
							<div id="ErrorHost" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>IP Address</label>
							<input class="form-control" type="text" name="ip" placeholder="IP Address">
							<div id="ErrorIp" class="form-control-error"></div>
						</div>
					</div>
					<!--<div class="col-md-6">
						<div class="form-group">
							<label>Port</label>
							<input class="form-control" type="number" name="port">
							<div id="ErrorPort" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Password</label>
							<input class="form-control" type="password" name="password">
							<div id="ErrorPassword" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Confirm Password</label>
							<input class="form-control" type="password" name="confirm_password">
							<div id="ErrorConfirmPassword" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Os Type</label>
						  <select class="form-control" id="os_type" name="os_type">
							  <option value="windows">Windows</option>
							  <option value="linux">Linux</option>
						  </select>
						  <div id="ErrorOs" class="form-control-error"></div>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>-->
					
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" id="addServer" onclick="addOnDB('insertServer')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>




<?php
if($key == 'addUser'){?>
	<div class="modal fade delete-modal" id="addFormModal" data-keyboard="false" data-backdrop="static">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertUser">
				<div class="row formtype">
				    <div class="col-md-6">
					   <div class="form-group">
						  <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="e.g. VT-0527" required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
				   
				    <div class="col-md-6">
						<div class="form-group">
							<label>Unix ID <span class="text-danger">*</span></label>
							<input class="form-control" type="text" name="unix_id" placeholder="e.g. E2705" >
							<div id="ErrorUnix" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name" placeholder="e.g. John" >
							<div id="ErrorFName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name" placeholder="e.g. Phillips" >
							<div id="ErrorLName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Email <span class="text-danger">*</span></label>
							<input class="form-control" type="email" name="email" placeholder="e.g. john.phillips@vodafone.com" onfocusout="validateEmail(this.value)"/>
							<div id="ErrorEmail" class="form-control-error"></div>
						</div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" id="insertUserBtn" onclick="addOnDB('insertUser')">Save</button>
				  <button type="reset" class="btn btn-secondary" onclick="reset()">Reset</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	  
	  
	  
	  <div class="modal fade delete-modal" id="assignServer" data-keyboard="false" data-backdrop="static">
	   <div class="modal-dialog modal-dialog-centered">
		 <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Assigne Server</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
		     <form id="assigneServerOnUserCreation">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Sever</label>
							<select class="form-control" id="grantServer" name="grantServer" onchange="getServerUser(this.value)">
								<option value="" disabled selected>Select Server</option>
								  <?php while($serverRow = $serverResult->fetch_assoc()){ ?>  
									<option value="<?php echo $serverRow['id']; ?>"> <?php echo $serverRow['host_name']; ?> </option>  
								<?php }?>
							</select>
							<div id="ErrorServer" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-12">
					  <div class="form-group">
						<div id="GetServerUser"></div>
					  </div>
					</div>
				  </div>
				 </form>
				</div>
				<div class="modal-footer float-right">
				  <button type="button" class="btn btn-danger" onclick="assigned('server')" id="addServerBtn">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
		  </div>
		  <!-- Modal body end-->
		 </div>
	   </div>
	   
	   
	   <div class="modal fade delete-modal" id="assignRole" data-keyboard="false" data-backdrop="static">
	   <div class="modal-dialog modal-dialog-centered">
		 <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Assigne Role</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
		     <form id="assigneRoleOnUserCreation">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Role</label>
							<select class="form-control" id="grantRole" name="grantRole">
								<option value="" disabled selected>Select Role</option>
								  <?php while($roleRow = $roleResult->fetch_assoc()){ ?>  
									<option value="<?php echo $roleRow['id']; ?>"> <?php echo $roleRow['role']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorRole" class="form-control-error"></div>
						</div>
					</div>
				  </div>
				 </form>
				</div>
				<div class="modal-footer float-right">
				  <button type="button" class="btn btn-danger" onclick="assigned('role')" id="addRoleBtn">Add</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
		  </div>
		 <!-- Modal body end-->
		</div>
	  </div>
<?php } ?>
