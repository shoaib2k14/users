<?php

$modalName = "addServerModal";

include('../controller/modal.php');

?>


<div class="modal fade delete-modal" id="addFormModal">
   <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Assign Server</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="rID" value="<?=$rID;?>">
				<input type="hidden" class="form-control" type="text" name="rMID" value="<?=$rMID;?>">
				<input type="hidden" class="form-control" type="text" name="key" value="insertConnects">
				<div class="row formtype">
				    <div class="col-md-12">
					   <div class="form-group">
					      <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" name="ticket_no" placeholder="Ticket number" required />
					   </div>
					</div>
					
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Server</label>
							<select class="form-control" name="server">
								<option value="" disabled selected>Select Server</option>
								  <?php while($sRow = $sResult->fetch_assoc()){ ?>  
									<option value="<?php echo $sRow['id']; ?>"> <?php echo $sRow['host_name']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorHost" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertConnects')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
      </div>
   </div>
</div>

