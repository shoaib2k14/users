<?php
include('../controller/getAssigneOrDelete.php');
?>

<style>
.source, .target{
	background: #f1f1f1;
    margin: 5px;
    padding-bottom: 20px;
    border-radius: 4px;
}

.source-heading, .target-heading{
	margin: 20px 5px 10px 5px;
}

.vertical-center{
	margin-top: 30px;
}
.form-control-success{
	font-size: 12px;
    text-align: start;
    font-weight: 400;
    color: #00c292 !important;
}
.display-none{
	display:none;
}
#validationMessage{
	display:none;
	padding-right: 15px;
    padding-left: 15px;
}

</style>

<?php 
if($_REQUEST['key'] == 'ServerUser'){ ?>
 <div class="modal fade delete-modal" id="addFormModal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add/Remove User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<div class="row formtype">
				    <div class="col-md-6">
					   <div class="form-group">
						  <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket"  placeholder="e.g. VT-0527"  required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label>Action <span class="text-danger">*</span></label>
						  <select class="form-control" id="action" name="action">
							  <option value="add">Add</option>
							  <option value="delete">Delete</option>
						  </select>
						  <div id="ErrorAction" class="form-control-error"></div>
					  </div>
					</div>
					
					<div class="col-md-12">
						<div class="form-group">
							<label>Select Server <span class="text-danger">*</span></label>
							<select class="form-control" id="server" name="server" required>
								<option value="" disabled selected>Select Server</option>
								  <?php while($sRow = $sResult->fetch_assoc()){ ?>  
									<option value="<?php echo $sRow['id']; ?>"> <?php echo $sRow['host_name']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorServer" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-12">
						<div class="form-group">
							<label>Service / Funnctional User<span class="text-danger">*</span></label>
							<input class="form-control" type="text" id="userName" name="userName" placeholder="e.g. jPhillips" autocomplete="false" required>
							<div id="ErrorUserName" class="form-control-error"></div>
						</div>
					</div>
					
					<!--
					<div class="col-md-5">
						<div class="form-group">
							<label>User Password<span class="text-danger">*</span></label>
							<input class="form-control" type="password" id="userPassword" name="userPassword" placeholder="********" autocomplete="new-password" required>
							<div id="ErrorPassword" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-2 vertical-center">
						<div class="form-group">
							<button type="button" id="validation" class="btn btn-success" onclick="validate()">Validate</button>
						</div>
					</div>
					-->
					
					<div id="validationMessage" class="form-control-error"></div>
					
					
					<div class="col-md-12">
						<div class="form-group">
							<label>User Owner Email<span class="text-danger">*</span></label>
							<!--
							<select class="form-control" id="user" name="user">
								<option value="" disabled selected>Select User</option>
								  <?php while($uRow = $uResult->fetch_assoc()){ ?>  
									<option value="<?php echo $uRow['id']; ?>"> <?php echo $uRow['email']; ?> </option>  
								  <?php }?>
							</select>
							-->
							<input class="form-control" type="text" id="user" name="user" placeholder="e.g. john.phillips@vodafone.com" onfocusout="validateEmail(this.value)" required>
							<div id="ErrorUser" class="form-control-error"></div>
						</div>
					</div>
					
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" id="saveServerUser" onclick="AssigneOrDelete('&key=UserServer')" disabled>Save</button>
				  <button type="reset" class="btn btn-secondary" onclick="reset()">Reset</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
      </div>
   </div>
<?php } 

if($_REQUEST['key'] == 'AddServerUser'){ ?>
  <div class="modal fade delete-modal" id="addFormModal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Password Encryption For Unix Servers</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<div class="row formtype">
				    <div class="col-md-12">
					   <div class="form-group">
						  <label>Reference Request ID<span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
				</div>
				
				<p class="source-heading">Fill Source Details </p>
				<div class="source row formtype">
				    <div class="col-md-6">
						<div class="form-group">
							<label>Select Source ServerName <span class="text-danger">*</span></label>
							<select class="form-control" id="sourceServer" name="sourceServer">
								<option value="" disabled selected>Select</option>
								  <?php while($sRow = $sResult->fetch_assoc()){ ?>  
									<option value="<?php echo $sRow['id']; ?>"> <?php echo $sRow['host_name']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorSourceServer" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<label>Source UserName<span class="text-danger">*</span></label>
							<input class="form-control" type="text" id="sourceUser" name="sourceUser" placeholder="Source User Name">
							<div id="ErrorSourceUser" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<label>Source Account Type<span class="text-danger">*</span></label>
							<select class="form-control" id="sourceAccountType" name="sourceAccountType">
								<option value="" disabled selected>Select</option>
								<option value="1">Service</option>
								<option value="2">Funnctional</option>
								<option value="3">Local</option>
							</select>
							<div id="ErrorAccountType" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-12">
						<div class="form-group">
							<label>Source UserName SSH Key<span class="text-danger">*</span></label>
							<textarea class="form-control" type="text" id="sourceSSHKey" name="sourceSSHKey" placeholder="Add SSH Key"/>
							<div id="ErrorSSH" class="form-control-error"></div>
						</div>
					</div>
				</div>
				
                <p  class="target-heading">Fill Target Details</p>		
				<div class="target row formtype">
					<div class="col-md-6">
						<div class="form-group">
							<label>Select Target ServerName <span class="text-danger">*</span></label>
							<select class="form-control" id="targetServer" name="targetServer">
								<option value="" disabled selected>Select</option>
								  <?php while($tRow = $tResult->fetch_assoc()){ ?>  
									<option value="<?php echo $tRow['id']; ?>"> <?php echo $tRow['host_name']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorTargetServer" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="form-group">
							<label>Target UserName<span class="text-danger">*</span></label>
							<input class="form-control" type="text" id="targetUser" name="targetUser" placeholder="Target User Name">
							<div id="ErrorTargetUser" class="form-control-error"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer float-right">
			  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
			  <button type="submit" class="btn btn-danger" onclick="addSSHKey('&key=AddUserServer')">Save</button>
			  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
		   </div>
		</form>
		 <!-- Modal body end-->
	  </div>
	</div>
  </div>
<?php } ?>

<script>
$(document).ready(function() {
  $('#sourceServer').select2({
		placeholder: "Select",
		allowClear: true
	});
	
  $('#targetServer').select2({
		placeholder: "Select",
		allowClear: true
	});
	
  $('#sourceAccountType').select2({
		placeholder: "Select",
		allowClear: true
	});
});
	   

</script>

