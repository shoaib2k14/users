<?php

$modalName = "grantModal";

include('../controller/modal.php');

?>


	<div class="modal fade delete-modal" id="getGrantPerUser">
	  <div class="modal-dialog modal-dialog-centered modal-xl">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title text-capitalize font-weight-light"><?php echo "Assigned to ".$user; ?></h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		    <div class="container">
			   <div class="row">
				 
				 <div class="col-sm-6 mb-3">
				   <div class="card mt-3 h-100">
					 <div class="card-header">Role</div>
					 <div class="card-body">
						<div class="table-responsive">
						   <table class="datatable table table-stripped table table-hover table-center mb-0">
						     <?php if(mysqli_num_rows($result_roles)>0){?>
								<thead>
									<tr>
										<th>#</th>
										<th>Role</th>
										<th>Servers</th>
										<th>Assigned On</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
						         <?php
								   foreach( $result_roles as $key=>$row ){ ?>
									  <tr>
										<td><?=++$key?></td>
										<td><?=$row["role"]?></td>
										<td>
										  <button class="btn btn-status p-0" onclick="getConnection('<?=$row["rid"]?>', '<?=$row["role"]?>')">
											<i class="fa fa-eye text-info"></i> View
										  </button>
										</td>
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<td>
										   <button type="submit" class="btn btn-success btn-status" onclick="updateStatusOnDB('<?=$row["id"]?>','dG','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Pending' ?>
										  </button>
										</td>
										
								  <?php } ?>
								</tbody>
							 <?php } else{ echo "No role assigned"; }?>
							</table>
						</div>
					 </div>
				  </div>  
				</div>
				
				<div class="col-sm-6 mb-3">
				   <div class="card mt-3 h-100">
					 <div class="card-header">Server</div>
					 <div class="card-body">
						<div class="table-responsive">
						   <table class="datatable table table-stripped table table-hover table-center mb-0">
							  <?php if(mysqli_num_rows($result_servers)>0){?>
								<thead>
									<tr>
										<th>#</th>
										<th>Server</th>
										<th>IP Address</th>
										<th>Assigned On</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
								  <?php
								     foreach( $result_servers as $key=>$row ){ ?>
									    <tr>
											<td><?=++$key?></td>
											<td class="text-lowercase"><?=$row["host_name"]?></td>
											<td><?=$row["ip_address"]?></td>
											<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
											<!--
											<td>
											   <button type="submit" class="btn btn-success btn-status" onclick="updateStatusOnDB('<?=$row["id"]?>','dG','<?=$row["status"]?>')">
												   <?php echo $row["status"] == 1 ? 'Active' : 'Pending' ?>
											    </button>
											</td>
											-->
											<td>
											 <?php 
											   if($row["status"] == 0) 
													 echo '<button class="btn btn-warning btn-status">Pending</button>';
											   
											   if($row["status"] == 1) 
													 echo '<button class="btn btn-success btn-status">Active</button>';
											   
											   if($row["status"] == 2) 
													 echo '<button class="btn btn-danger btn-status">Declined</button>';
											 ?>
									       </td>
									  </tr>
										</tr>
								   <?php } ?>
								</tbody>
							  <?php } else{ echo "No server assigned";} ?>
							</table>
						 </div>
					  </div>
				   </div>  
			    </div>
				
			  </div>
			</div>
		  <!-- Modal body end-->
		  
		  <!-- Modal footer -->
		  <div class="modal-footer float-right">
				<button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
		  </div>
		  <!-- Modal footer end-->
		  
		</div>
	   </div>
	 </div>
