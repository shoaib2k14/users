<?php
include('../../dbConnection.php');

echo $market = trim($_POST['market']);


switch($market){
	case 'group':
	echo '<option value="VF-GLOBAL">VF-GLOBAL AUTOMATION SOLUTION PLATEFORM-PROD</option>
		  <option value="COMMON">COMMON SERVICES-BACKUP AND RECOVERY</option>';
	break;
	
	case 'germany':
	echo '<option value="PUA">DE-KIAS CUSTOMER-CUSTOMER PUA</option>
		  <option value="PUC">DE-KIAS CUSTOMER-CUSTOMER PUC</option>
		  <option value="MMO">DE-KIAS CUSTOMER-CUSTOMER MMO</option>';
	break;
	
	case 'italy':
	echo '<option value="IT-CCM">IT-CCM</option>
		  <option value="IT-CRM">IT-CRM</option>
		  <option value="IT-MP">IT-MP</option>';
	break;
	
	case 'spain':
	echo '<option value="ES-ARBOR">ES-ARBOR</option>';
	break;
}
?> 
 
<script> 
$(document).ready(function() {
	$('#service').select2({
		placeholder: "--Select Service--",
		allowClear: true
	});
});
</script>