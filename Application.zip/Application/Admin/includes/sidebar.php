<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							
							<li id="dashboard">
								<a href="dashboard.php"><i class="fa fa-desktop"></i></a>
								<p class="sidebar-txt">Dashboard</p>
							</li>
							
							<li id="Manual" class="">
								<a href="manual-restart.php"><i class="fa fa-user-o"></i></a>
								<p class="sidebar-txt">Manual<br/>Restart</p>
							</li>
							
							<li id="Schedule" class="">
								<a href="schedule-restart.php"><i class="fa fa-bookmark-o"></i></a>
								<p class="sidebar-txt">Schedule<br/>Restart</p> 
							</li>
							
							<li id="Logs" class="">
								<a href="logs.php"><i class="fa fa-ticket"></i></a>
								<p class="sidebar-txt">Logs</p> 
							</li>
							
							<li id="User" class="">
								<a href="user-management.php"><i class="fa fa-cloud"></i></a>
								<p class="sidebar-txt">User<br/>Management</p> 
							</li>
							
						    <li class="list-divider"></li>
							
							<li>
							  <a href="../logout.php?key=0"><i class="fa fa-sign-out"></i></a>
							  <p class="sidebar-txt">Logout </p> 
							<li>
						
						</ul>
					</div>
				</div>
			</div>
<!-- /Sidebar -->